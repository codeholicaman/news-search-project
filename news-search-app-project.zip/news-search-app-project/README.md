# News Search Microservice

## Overview

This project is a full-stack application that provides a microservice to search for news articles based on a keyword. The results are grouped into intervals (e.g., minutes, hours, days) specified by the user and are displayed on a web interface. The backend is built with Java (Spring Boot), and the frontend uses Angular. The application also supports offline mode and caching to handle cases where the external news API is unavailable.

## Features

- **Search News**: Enter a keyword to search for news articles.
- **Group by Interval**: Results are grouped into time intervals such as minutes, hours, days, etc.
- **Caching**: Cache results to handle API downtime.
- **Offline Mode**: Toggle offline mode to view cached results when the API is unavailable.
- **Dockerized**: The application is containerized using Docker for easy deployment.
- **CI/CD Pipeline**: Integrated with Jenkins to automate the build, test, and deployment process.

## Architecture

- **Backend**: Java with Spring Boot, REST API.
- **Frontend**: Angular, HTML, CSS.
- **Database**: In-memory caching (no external DB).
- **External API**: NewsAPI's Everything API.
- **Build Tools**: Maven (backend), npm (frontend).
- **Containerization**: Docker.
- **CI/CD**: Jenkins, with build pipeline running on Windows Subsystem for Linux (WSL).

## Requirements

- Java 17+
- Node.js 
- Angular CLI
- Docker
- Jenkins
- linux/ubuntu

## Setup and Installation

### Backend

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/your-repo/news-search-app.git
   cd news-search-app/backend
   
2. run the pipeline jenkins job to deploy the news-search-app image

#To manually build the project and run 

  1. run mvn clean install from news-search-app
  2. go to backend folder - cd backend/
  3. run mvn spring-boot:run

#swagger url - http://localhost:8443/swagger-ui/index.html

app ui - http://localhost:8443