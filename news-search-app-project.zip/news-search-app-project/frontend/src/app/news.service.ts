import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  // private apiUrl = 'https://newsapi.org/v2/everything?q=';
  private apiUrl = 'http://localhost:8443/api/news?query=';
  private cacheApiUrl = 'http://localhost:8443/api/news/cache';
  private apiKey='ccaf5d41cc5140c984818c344edcc14d';
  private fallbackNews: any = [{
    status: 'fallback',
    totalResults: 2,
    articles: [
      {
        title: 'Fallback News 1',
        description: 'This is a fallback news article due to API unavailability.',
        url: 'https://example.com/fallback-news-1',
        publishedAt: '2024-08-07T00:00:00Z'
      },
      {
        title: 'Fallback News 2',
        description: 'Another fallback news article due to API unavailability.',
        url: 'https://example.com/fallback-news-2',
        publishedAt: '2024-08-06T00:00:00Z'
      }
    ]
  }];

  constructor(private http: HttpClient) { }

  getNews(query:string,interval:string,unit:string): Observable<any> {
    // return this.http.get<any>(`${this.apiUrl}${query}&apiKey=${this.apiKey}`);
     let fullUrl = `${this.apiUrl}${query}`;
    if (interval && interval !== '') {
        fullUrl += `&n=${interval}`;
      }
    if (unit && unit !== '') {
     fullUrl += `&interval=${unit}`;
    }
    return this.http.get<any>(fullUrl)
                  .pipe(
                    catchError(this.handleError)
                  );
  }

  getOfflineNews(): Observable<any> {
    // Return fallback data when in offline mode
    return  this.http.get<any>(this.cacheApiUrl);
  }

 private handleError(error: HttpErrorResponse) {
     let errorMessage = 'An unknown error occurred!';
     if (error.error instanceof ErrorEvent) {
       // Client-side or network error
       errorMessage = `Error: ${error.error.message}`;
     } else {
       // Backend returned an unsuccessful response code.
       // The response body may contain clues as to what went wrong.
       if (error.error.message) {
         errorMessage = `Error ${error.status}: ${error.error.message}`;
       } else {
         errorMessage = `Error ${error.status}: ${error.message}`;
       }
     }
     return throwError(errorMessage);
   }

}

