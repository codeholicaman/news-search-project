import { Component } from '@angular/core';
import { NewsService } from '../news.service';

@Component({
  selector: 'app-news-search',
  templateUrl: './news-search.component.html',
  styleUrls: ['./news-search.component.scss']
})
export class NewsSearchComponent {
  query: string = '';
  interval: string = '';
  selectedUnit: string = '';
  units=['hours','minutes','days','weeks','months']
  newsResponse: any = null;
  isOfflineMode: boolean = false;
    errorMessage = '';

  constructor(private newsService: NewsService) { }

  toggleOfflineMode(): void {
    this.isOfflineMode = !this.isOfflineMode;
    if (this.isOfflineMode) {
      this.newsService.getOfflineNews().subscribe((response: any) => {
        this.newsResponse = response;
      });
    } else {
      this.searchNews();
    }
  }


  searchNews() {
    if (this.isOfflineMode) {
      this.newsService.getOfflineNews().subscribe((response: any) => {
        this.newsResponse = response;
      });
    }
     else{
       this.errorMessage = ''; // Reset error message
      this.newsService.getNews(this.query,this.interval,this.selectedUnit).subscribe((response) => {
      this.newsResponse = response;
    },
     (error) => {
              this.errorMessage = error;
            }
  );
  }
  }

  groupByInterval(articles: any[]) {
    // Implement the logic to group articles by intervals
    // This is a placeholder logic
    return [{
      interval: 'Last 12 Hours',
      articles: articles
    },{
      interval:'Last 24 hours',
      articles:articles
    }];
  }
}
