#!/bin/bash

echo "Running tests..."
mvn test