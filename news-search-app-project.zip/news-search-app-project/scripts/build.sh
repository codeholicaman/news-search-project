#!/bin/bash

echo "Building the project..."
mvn clean install -DskipTests