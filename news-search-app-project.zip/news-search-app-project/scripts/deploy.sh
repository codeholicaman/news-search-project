#!/bin/bash

echo "Deploying the Docker container..."
docker run -d -p 8080:8080 --name news-project news-project:latest