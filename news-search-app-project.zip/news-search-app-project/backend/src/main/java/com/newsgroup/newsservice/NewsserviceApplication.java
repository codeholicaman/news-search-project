package com.newsgroup.newsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsserviceApplication.class, args);
	}

}
