package com.newsgroup.newsservice.exception;

public class NewsNotFoundException extends RuntimeException {
    public NewsNotFoundException(String message)  {
        super(message);
    }
}
