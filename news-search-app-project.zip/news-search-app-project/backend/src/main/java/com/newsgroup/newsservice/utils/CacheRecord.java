package com.newsgroup.newsservice.utils;

import com.newsgroup.newsservice.model.Article;

import java.util.List;

public class CacheRecord {

    private List<Article> articles;

    private long timestamp;

    CacheRecord(List<Article> articles, long timestamp) {
        this.articles = articles;
        this.timestamp = timestamp;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }
    public List<Article> getArticles(){
        return this.articles;
    }
    public long getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }


}
