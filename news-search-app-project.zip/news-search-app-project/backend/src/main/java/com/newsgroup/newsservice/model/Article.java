package com.newsgroup.newsservice.model;


import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Article {

    private String title;
    private String description;
    private String url;
    private String publishedAt;
}
