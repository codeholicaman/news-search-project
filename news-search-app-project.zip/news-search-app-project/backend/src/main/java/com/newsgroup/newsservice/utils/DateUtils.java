package com.newsgroup.newsservice.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DateUtils {

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

    public static Date parseDate(String dateStr) {
        try {
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            return null;
        }
    }


    public static long calculateIntervalInMinutes(int n, String interval) {
        switch (interval.toLowerCase()) {
            case "minutes":
                return n;
            case "hours":
                return TimeUnit.HOURS.toMinutes(n);
            case "days":
                return TimeUnit.DAYS.toMinutes(n);
            case "weeks":
                return TimeUnit.DAYS.toMinutes(7 * n);
            case "months":
                return TimeUnit.DAYS.toMinutes(30 * n);
            default:
                throw new IllegalArgumentException("Invalid interval: " + interval);
        }
    }

    public static long getDateDifferenceInMinutes(Date date1, Date date2) {
        long diffInMillis = Math.abs(date2.getTime() - date1.getTime());
        return TimeUnit.MILLISECONDS.toMinutes(diffInMillis);
    }

}
