package com.newsgroup.newsservice.utils;

import com.newsgroup.newsservice.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

@Component
public class NewsCache {


    // A map to store cached data with the search keyword as the key
    private final Map<String, CacheRecord> cache = new ConcurrentHashMap<>();
    private static final long CACHE_EXPIRATION_TIME = TimeUnit.MINUTES.toMillis(60); // 10 minutes in milliseconds

    // A class to represent a cache entry


    // Method to get cached articles for a keyword
    public List<Article> get(String keyword) {
        CacheRecord record = cache.get(keyword);
        List<Article> articles = null;
        if (record != null) {
            long currentTime = System.currentTimeMillis();
            // Check if the cache entry is still valid (not expired)
            if (currentTime - record.getTimestamp() < CACHE_EXPIRATION_TIME) {
                articles = record.getArticles();
            } else {
                // If the cache entry is expired, remove it
                cache.remove(keyword);
            }
        }
        return articles;
    }

    // Method to put articles into the cache
    public void put(String keyword, List<Article> articles) {
        long currentTime = System.currentTimeMillis();
        cache.put(keyword, new CacheRecord(articles, currentTime));
    }

    // Method to check if cache has valid data for a keyword
    public boolean contains(String keyword) {
        CacheRecord entry = cache.get(keyword);
        if (entry != null) {
            long currentTime = System.currentTimeMillis();
            // Check if the cache entry is still valid (not expired)
            if (currentTime - entry.getTimestamp() < CACHE_EXPIRATION_TIME) {
                return true;
            } else {
                // If the cache entry is expired, remove it
                cache.remove(keyword);
            }
        }
        return false;
    }

    public Map<String, CacheRecord> getCache(){
        return  this.cache;
    }
}
