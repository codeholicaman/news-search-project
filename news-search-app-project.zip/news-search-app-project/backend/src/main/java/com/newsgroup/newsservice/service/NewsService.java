package com.newsgroup.newsservice.service;


import com.newsgroup.newsservice.exception.NewsNotFoundException;
import com.newsgroup.newsservice.model.Article;
import com.newsgroup.newsservice.model.NewsResponse;
import com.newsgroup.newsservice.utils.CacheRecord;
import com.newsgroup.newsservice.utils.NewsCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

import static com.newsgroup.newsservice.utils.DateUtils.*;

@Service
public class NewsService {

    @Value("${newsapi.key}")
    private String apiKey;

    private final NewsCache newsCache;

    private final RestTemplate restTemplate;

    public static final String EVERYTHING_NEWS_API = "https://newsapi.org/v2/everything?q=";

    public NewsService(NewsCache newsCache,RestTemplate restTemplate) {
        this.newsCache = newsCache;
        this.restTemplate = restTemplate;

    }


    public List<Map<String, Object>> getNews(String query, int n , String interval) {
        List<Article> articles = null;
        List<Map<String, Object>> response = null;
        try {
            if (query == null || query.isEmpty()) {
                throw new NewsNotFoundException("Keyword is required for searching news.");
            }
            // check if cache already contains news keyword
            // if it contains fetch the articles list from cache no need to make API call
            // if not then fetch articles using everything news api and update cache
            if (newsCache.contains(query)) {
                articles = newsCache.get(query);
            } else {
                articles = fetchFromAPI(query);

                if (articles != null && !articles.isEmpty()) {
                    newsCache.put(query, articles);
                }
            }
            Date currentDateTime = new Date();
            response = groupByInterval(articles, n,interval,currentDateTime);
        }
        catch (Exception e){
            if (e instanceof NewsNotFoundException){
                throw (NewsNotFoundException)e;
            }else{
                throw e;
            }


        }
        return response;
    }

    private List<Article> fetchFromAPI(String query) {
        String url = EVERYTHING_NEWS_API + query + "&apiKey=" + apiKey;
        NewsResponse newsResponse = restTemplate.getForObject(url, NewsResponse.class);
        return newsResponse.getArticles();
    }

    public List<Map<String, Object>> groupByInterval(List<Article> articles, int n, String interval, Date currentDateTime) {
        // group artcles by intervals
        // calculate current date time for using it as a reference -
        //convert it into minutes
        // for each article calculate duration between the article published and current date
        //divide the duration in minutes with the interval converted into minutes for groupinh the articles
        long intervalInMinutes = calculateIntervalInMinutes(n, interval);
        return   articles
                .stream()
                .collect(Collectors.groupingBy(article -> {
                    Date publishedAt =parseDate(article.getPublishedAt());
                    long diffInMinutes = getDateDifferenceInMinutes(publishedAt, currentDateTime);
                    return diffInMinutes / intervalInMinutes;
                }))
                .entrySet().stream() // Convert the map to a stream of entries
                .map(entry -> { // Map each entry to the required result structure
                    Map<String, Object> group = new HashMap<>();
                    group.put("intervalGroup", entry.getKey());
                    group.put("count", entry.getValue().size());
                    group.put("articles", entry.getValue());
                    return group;
                })
                .collect(Collectors.toList());

    }


    public List<Map<String, Object>> getCacheData() {
        List<Article> articles = null;
        Map<String, CacheRecord> cache = newsCache.getCache();

       return cache.entrySet().stream()
                .map(entry -> { // Map each entry to the required result structure
                    Map<String, Object> group = new HashMap<>();
                    CacheRecord cacheRecord = entry.getValue();
                    group.put("keyword", entry.getKey());
                    group.put("count", cacheRecord.getArticles().size());
                    group.put("articles", cacheRecord.getArticles());
                    return group;
               })
                .collect(Collectors.toList());


    }
}
