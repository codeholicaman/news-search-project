package com.newsgroup.newsservice.model;

import lombok.*;

import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NewsResponse {

    private String status;
    private int totalResults;
    private List<Article> articles;
}
