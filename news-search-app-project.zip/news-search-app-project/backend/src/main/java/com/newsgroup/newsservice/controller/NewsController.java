package com.newsgroup.newsservice.controller;

import com.newsgroup.newsservice.model.NewsResponse;
import com.newsgroup.newsservice.service.NewsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/news")
@Tag(name = "News", description = "News Search API")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping
    @Operation(summary = "Search news by keyword", description = "Finds relevant news for a particular keyword")
    public ResponseEntity<List<Map<String, Object>>> getNews(@RequestParam(required = true) String query, @RequestParam(required = false, defaultValue = "12") int n, @RequestParam(required = false, defaultValue = "hours") String interval) {
        return new ResponseEntity<>(newsService.getNews(query, n, interval), ResponseEntity.ok().build().getStatusCode());
    }

    // api to fetch cache in offline mode
    @GetMapping("/cache")
    @Operation(summary = "Fetch news in offline mode", description = "get cached news articles in offline mode")
    public ResponseEntity<List<Map<String, Object>>> getCacheData() {
        return new ResponseEntity<>(newsService.getCacheData(), ResponseEntity.ok().build().getStatusCode());
    }
}
