package com.newsgroup.newsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
